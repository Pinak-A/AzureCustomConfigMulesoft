package com.mulesoft.azure.vault.provider.api.jce;

public enum EncryptionPadding {
    PKCS5Padding, PKCS1PADDING;
}